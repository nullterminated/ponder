To use these project templates, move them to your ~/Library/Application Support/WOLips/Project Templates/ directory and follow the instructions found here:

http://wiki.objectstyle.org/confluence/display/WOL/Custom+Project+Templates

If you create a localized project using these templates, you will need to set the character set to UTF-16BE on the .strings files located in the various .lproj folders in the Resources folder as well.