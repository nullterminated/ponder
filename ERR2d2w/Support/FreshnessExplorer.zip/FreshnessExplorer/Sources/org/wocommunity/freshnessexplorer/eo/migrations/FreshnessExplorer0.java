package org.wocommunity.freshnessexplorer.eo.migrations;

import org.wocommunity.freshnessexplorer.eo.server.Person;

import com.webobjects.eoaccess.EOModel;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSTimestamp;

import er.extensions.migration.ERXMigrationDatabase;
import er.extensions.migration.ERXMigrationTable;
import er.extensions.migration.ERXModelVersion;
import er.extensions.migration.IERXPostMigration;

public class FreshnessExplorer0 extends ERXMigrationDatabase.Migration implements IERXPostMigration {
	@Override
	public NSArray<ERXModelVersion> modelDependencies() {
		return null;
	}

	@Override
	public void downgrade(EOEditingContext editingContext,
			ERXMigrationDatabase database) throws Throwable {
		// DO NOTHING
	}

	@Override
	public void upgrade(EOEditingContext editingContext,
			ERXMigrationDatabase database) throws Throwable {
		
		ERXMigrationTable personTable = database.newTableNamed("PERSON");
		personTable.newTimestampColumn("BIRTHDAY", true);
		personTable.newStringColumn("FIRST_NAME", 255, true);
		personTable.newIntegerColumn("ID", false);
		personTable.newStringColumn("LAST_NAME", 255, true);
		personTable.create();
		personTable.setPrimaryKey("ID");
	}
	
	public void postUpgrade(EOEditingContext editingContext, EOModel model) throws Throwable {
		Person p = Person.createPerson(editingContext);
		p.setBirthday(new NSTimestamp());
		p.setFirstName("John");
		p.setLastName("Smith");
	}
}