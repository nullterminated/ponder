package org.wocommunity.freshnessexplorer.ui.web.components;

import com.webobjects.appserver.WOContext;
import com.webobjects.foundation.NSTimestamp;

import er.extensions.components.ERXComponent;

public class Main extends ERXComponent {
	public Main(WOContext context) {
		super(context);
	}
	
	public NSTimestamp currentDate() {
        return new NSTimestamp();
    }
}
