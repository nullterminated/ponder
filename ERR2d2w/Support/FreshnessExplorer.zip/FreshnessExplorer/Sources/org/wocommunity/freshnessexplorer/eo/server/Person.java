package org.wocommunity.freshnessexplorer.eo.server;

import org.apache.log4j.Logger;

public class Person extends _Person {
  private static Logger log = Logger.getLogger(Person.class);
}
