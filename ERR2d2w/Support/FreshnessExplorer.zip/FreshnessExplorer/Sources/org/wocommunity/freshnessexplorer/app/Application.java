package org.wocommunity.freshnessexplorer.app;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORequest;
import com.webobjects.eoaccess.EOAdaptorContext;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.eocontrol.EOObjectStoreCoordinator;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSDictionary;

import er.extensions.appserver.ERXApplication;

public class Application extends ERXApplication {
	
    public NSDictionary rawRow;
    public EOEditingContext rawRowContext;
    public String currentKey;
    public Object currentValue;
    
    public EOGlobalID gid;
    
    public static void main(String[] argv) {
		ERXApplication.main(argv, Application.class);
	}

	public Application() {
		ERXApplication.log.info("Welcome to " + name() + " !");
		/* ** put your initialization code in here ** */
		
		EOAdaptorContext.setDefaultDelegate(LogForDisplay.sharedLog());
        rawRowContext = new EOEditingContext(new EOObjectStoreCoordinator());        		
	}
	
	public EOGlobalID gid() {
        return gid;
    }
    
    public void setGid(EOGlobalID value) {
        gid = value;
    }
    
    @Override
    public WOActionResults invokeAction(WORequest r, WOContext c) {
        WOActionResults ar = super.invokeAction(r, c);
        fetchRawRow();
        return ar;
    }
    
    public void fetchRawRow() {
        NSArray array = EOUtilities.rawRowsMatchingKeyAndValue(rawRowContext, "Person", "id", new Integer(1));
        if (array != null && array.count() > 0) {
            rawRow = (NSDictionary) array.objectAtIndex(0);
        }        
    }
                
}
