package org.wocommunity.freshnessexplorer.ui.web.components;

//
// StackView.java: Class file for WO Component 'StackView'
// Project FreshnessExplorer
//
// Created by dempseyj on Fri Jun 25 2004
//

import org.apache.log4j.Logger;
import org.wocommunity.freshnessexplorer.app.LogForDisplay;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.eoaccess.EODatabase;
import com.webobjects.eoaccess.EODatabaseContext;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.eocontrol.EOObjectStoreCoordinator;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSMutableArray;
import com.webobjects.foundation.NSTimestamp;

public class StackView extends EOViewerComponent {
	private static final Logger log = Logger.getLogger(StackView.class);
	
    public String currentKey;
    public Object currentValue;
		
    public EOObjectStoreCoordinator osc;

    public String lastSQLString;
	
	public static int instanceCount = 0;
	public int instanceNumber;
	
    public EOEditingContext currentEditingContext;

    /** @TypeInfo EOEditingContexts */
    public NSMutableArray editingContexts;

    public StackView(WOContext context) {
        super(context);
		EditingContextView.instanceCount = 0;

		osc = new EOObjectStoreCoordinator();
		editingContexts = new NSMutableArray();
		for (int i = 0; i < 2; i++) {
			EOEditingContext editingContext = new EOEditingContext(osc);
			editingContexts.addObject(editingContext);
		}
		instanceCount++;
		instanceNumber = instanceCount;
		lastSQLString = "";
	
    }
	
	public boolean synchronizesVariablesWithBindings() {
		return false;
	}
	
	public boolean isStateless() {
		return false;
	}
	
	public String tableTitle() {
		return "EOF Stack #" + valueForBinding("stackNumber");
	}
	
	public boolean lastSQLStringIsEmpty() {
		log.info("Last SQL String: " + lastSQLString);
		return lastSQLString.equals("");
	}
	
	// clear the SQL log before any action is taken
	public WOActionResults invokeAction(WORequest r, WOContext c) {
		LogForDisplay.sharedLog().resetLog();
		WOActionResults ar = super.invokeAction(r, c);
		lastSQLString = LogForDisplay.sharedLog().log();
		return ar;
	}
	
	public void appendToResponse(WOResponse r, WOContext c) {
		super.appendToResponse(r, c);
		// clear the last SQL string after page is generated
		lastSQLString="";
	}
	
	
	public int instanceNumber() {
		return instanceNumber;
	}
	
		
	public NSDictionary currentSnapshot() {
		return currentSnapshotForGlobalID(gid());
	}
	
	public NSDictionary currentSnapshotForGlobalID(EOGlobalID gid) {
		NSDictionary snapshot = null;
		if (gid != null) {
			log.info("gid is " + gid);
			
			log.info("Is osc null? " + osc);
			
			
			EODatabaseContext databaseContext = (EODatabaseContext) osc.objectStoreForGlobalID(gid);
			log.info("Is databaseContext null? " + databaseContext);
			
			EODatabase database = databaseContext.database();
			log.info("Is database null? " + database);
			snapshot = database.snapshotForGlobalID(gid);
			log.info("Is snapshot null? " + snapshot);
			
		}
		return snapshot;
	}
	
	public NSTimestamp currentFetchTimestamp() {
		return currentFetchTimestampForGlobalID(gid());
	}
	
	public NSTimestamp currentFetchTimestampForGlobalID(EOGlobalID gid) {
		NSTimestamp fetchTimestamp = null;
		if (gid != null) {
			log.info("gid is " + gid);
			
			log.info("Is osc null? " + osc);
			
			
			EODatabaseContext databaseContext = (EODatabaseContext) osc.objectStoreForGlobalID(gid);
			log.info("Is databaseContext null? " + databaseContext);
			
			EODatabase database = databaseContext.database();
			log.info("Is database null? " + database);
			fetchTimestamp = new NSTimestamp(database.timestampForGlobalID(gid));
			log.info("Is fetchTimestamp null? " + fetchTimestamp);
			
		}
		return fetchTimestamp;
	}
	

   

}


/*
 IMPORTANT:  This Apple software is supplied to you by Apple Computer, Inc. ("Apple") in
 consideration of your agreement to the following terms, and your use, installation, 
 modification or redistribution of this Apple software constitutes acceptance of these 
 terms.  If you do not agree with these terms, please do not use, install, modify or 
 redistribute this Apple software.
 
 In consideration of your agreement to abide by the following terms, and subject to these 
 terms, Apple grants you a personal, non-exclusive license, under Apple�s copyrights in 
 this original Apple software (the "Apple Software"), to use, reproduce, modify and 
 redistribute the Apple Software, with or without modifications, in source and/or binary 
 forms; provided that if you redistribute the Apple Software in its entirety and without 
 modifications, you must retain this notice and the following text and disclaimers in all 
 such redistributions of the Apple Software.  Neither the name, trademarks, service marks 
 or logos of Apple Computer, Inc. may be used to endorse or promote products derived from 
 the Apple Software without specific prior written permission from Apple. Except as expressly
 stated in this notice, no other rights or licenses, express or implied, are granted by Apple
 herein, including but not limited to any patent rights that may be infringed by your 
 derivative works or by other works in which the Apple Software may be incorporated.
 
 The Apple Software is provided by Apple on an "AS IS" basis.  APPLE MAKES NO WARRANTIES, 
 EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, 
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS 
 USE AND OPERATION ALONE OR IN COMBINATION WITH YOUR PRODUCTS.
 
 IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL OR CONSEQUENTIAL 
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS 
 OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, 
 REPRODUCTION, MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED AND 
 WHETHER UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR 
 OTHERWISE, EVEN IF APPLE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
