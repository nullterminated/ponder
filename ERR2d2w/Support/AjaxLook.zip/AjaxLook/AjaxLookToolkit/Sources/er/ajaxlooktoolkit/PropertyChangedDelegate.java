package er.ajaxlooktoolkit;

import com.webobjects.directtoweb.D2WContext;
import com.webobjects.foundation.NSArray;

public interface PropertyChangedDelegate {
	/**
	 * 
	 * @param context The d2wContext of the changed property level component
	 * @return 
	 */
	public NSArray<String> propertyChanged(D2WContext context);
}
