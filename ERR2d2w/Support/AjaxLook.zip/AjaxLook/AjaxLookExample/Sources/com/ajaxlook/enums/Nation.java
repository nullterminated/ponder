package com.ajaxlook.enums;

public enum Nation {
	US, UK;
}
