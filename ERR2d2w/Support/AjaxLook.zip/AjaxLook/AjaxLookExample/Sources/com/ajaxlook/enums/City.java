package com.ajaxlook.enums;

public enum City {
	MIAMI, ORLANDO, ATLANTA, SAVANNAH, CARDIFF, BANGOR, DUNDEE, GLASGOW;
}
