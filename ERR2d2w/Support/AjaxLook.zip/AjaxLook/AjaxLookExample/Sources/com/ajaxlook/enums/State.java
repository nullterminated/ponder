package com.ajaxlook.enums;

public enum State {
	FLORIDA, GEORGIA, WALES, SCOTLAND;
}
