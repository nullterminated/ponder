package com.ajaxlook.components;

import com.webobjects.appserver.*;
import com.webobjects.directtoweb.D2WPage;
import com.webobjects.directtoweb.D2WContext;

public class PageWrapper extends WOComponent {

    public PageWrapper(WOContext aContext) {
        super(aContext);
    }
    public D2WContext d2wContext() {
    	if (context().page() instanceof D2WPage) {
			D2WPage d2wPage = (D2WPage) context().page();
			return d2wPage.d2wContext();
		}
    	return null;
    }
}
